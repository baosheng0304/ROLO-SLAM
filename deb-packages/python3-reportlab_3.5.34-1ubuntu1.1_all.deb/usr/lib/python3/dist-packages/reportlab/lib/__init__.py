#! /usr/bin/python3
#Copyright ReportLab Europe Ltd. 2000-2017
#see license.txt for license details
#history https://hg.reportlab.com/hg-public/reportlab/log/tip/src/reportlab/lib/__init__.py
__version__='3.3.0'
import os
RL_DEBUG = 'RL_DEBUG' in os.environ
