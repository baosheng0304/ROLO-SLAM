/* This file is auto generated, version 149~20.04.1-Ubuntu */
/* SMP */
#define UTS_MACHINE "x86_64"
#define UTS_VERSION "#149~20.04.1-Ubuntu SMP Wed Apr 16 08:29:56 UTC 2025"
#define LINUX_COMPILE_BY "buildd"
#define LINUX_COMPILE_HOST "lcy02-amd64-067"
#define LINUX_COMPILER "gcc (Ubuntu 9.4.0-1ubuntu1~20.04.2) 9.4.0, GNU ld (GNU Binutils for Ubuntu) 2.34"
